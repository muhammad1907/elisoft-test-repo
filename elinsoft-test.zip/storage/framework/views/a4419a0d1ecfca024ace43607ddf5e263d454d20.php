<footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer><?php /**PATH E:\Kerja\Test\elinsoft-test\resources\views/includes/footer.blade.php ENDPATH**/ ?>